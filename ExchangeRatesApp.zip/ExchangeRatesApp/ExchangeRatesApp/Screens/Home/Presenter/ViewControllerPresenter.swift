//
//  VCPresenter.swift
//  ExchangeRatesApp
//
//  Created by Mai Alaa on 5/28/19.
//  Copyright © 2019 Mai Alaa. All rights reserved.
//

import Foundation

class ViewControllerPresenter: NSObject {
    var networkManager : NetworkManager?
    var viewProtocol : ViewControllerProtocol?
    
    override init(){
        super.init()
        self.networkManager = NetworkManager(presenter: self)
    }
    
    func setDelegate(delegate: ViewControllerProtocol) {
        self.viewProtocol = delegate
    }
    
    //Method to callnetwork service method (to initiate async network service)
    func getCurrencyObjFromNS(){
        networkManager?.getJsonResponse()
    }
    
    //Method to take concurrency object from network to view
    func sendCurrencyObjToView(currencyObj: Currency) {
        viewProtocol?.showCurrencyRatesInTableView(currencyObj: currencyObj)
    }
    

}

