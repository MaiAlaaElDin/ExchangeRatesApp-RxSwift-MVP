//
//  VCProtocol.swift
//  ExchangeRatesApp
//
//  Created by Mai Alaa on 5/28/19.
//  Copyright © 2019 Mai Alaa. All rights reserved.
//

import Foundation
