//
//  NetworkConnection.swift
//  ExchangeRatesApp
//
//  Created by Mai Alaa on 5/27/19.
//  Copyright © 2019 Mai Alaa. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import RxAlamofire

var apiStr = "https://api.exchangeratesapi.io/latest"
//var request : URLRequest?
//var url : URL?

class NetworkManager: NSObject {
    
    var vcPresenter : ViewControllerPresenter?
    var currencyObject : Currency?
    let disposeBag = DisposeBag()
    
    init(presenter : ViewControllerPresenter) {
        self.vcPresenter = presenter
    }
    
//    func prepareRequest(apiStr: String){
//        url = URL(string: apiStr)
//        request = URLRequest(url: url!)
//    }
    
    func getJsonResponse() {
        _ = RxAlamofire.requestJSON(.get, apiStr)
            .debug()
            .subscribe(onNext: { [weak self] (r, json) in

                if json is Dictionary<String, Any>{
                do{
                let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
                
                    self?.currencyObject = try? JSONDecoder().decode(Currency.self, from: jsonData)
                    //print(self?.currencyObject!)
                self?.sendCurrenctObjToPresenter(currencyObj: (self?.currencyObject!)!)
                }
                    catch{print("Error in parsing json")}
                }
                }, onError: {(error) in print(error as NSError)
            
            }).disposed(by: disposeBag)
        
    }
    
    func sendCurrenctObjToPresenter(currencyObj: Currency)  {
        vcPresenter?.sendCurrencyObjToView(currencyObj: currencyObj)
    }
}
