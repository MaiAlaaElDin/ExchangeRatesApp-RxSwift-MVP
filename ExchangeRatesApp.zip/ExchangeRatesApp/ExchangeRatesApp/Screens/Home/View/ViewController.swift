//
//  ViewController.swift
//  ExchangeRatesApp
//
//  Created by Mai Alaa on 5/27/19.
//  Copyright © 2019 Mai Alaa. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa


class ViewController: UIViewController {

    @IBOutlet weak var currencyTableView: UITableView!
    var presenter : ViewControllerPresenter = ViewControllerPresenter()
    var myCurrencyRate : Currency?
    var ratesDict : Dictionary<String, Double>?
    var countriesArray = Array<String> ()
    var currenciesArray = Array<String>()
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.presenter.setDelegate(delegate: self as ViewControllerProtocol)
        
        getCurrencyRatesList()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    


}

