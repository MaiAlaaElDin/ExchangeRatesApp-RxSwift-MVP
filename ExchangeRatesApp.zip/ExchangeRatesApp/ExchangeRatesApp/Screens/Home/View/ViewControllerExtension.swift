//
//  ViewControllerExtension.swift
//  ExchangeRatesApp
//
//  Created by Mai Alaa on 5/28/19.
//  Copyright © 2019 Mai Alaa. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

extension ViewController : ViewControllerProtocol{
    
    func showCurrencyRatesInTableView(currencyObj: Currency) {
        self.myCurrencyRate = currencyObj
        self.ratesDict = currencyObj.rates
        
        for (key, value) in self.ratesDict! {
            self.countriesArray.append("\(key)")
            self.currenciesArray.append(" \(value)")
        }
        
        let ratesObservable = Observable.of(self.countriesArray)
        //Show currency rates on table view labels
        ratesObservable.bind(to: self.currencyTableView.rx.items(cellIdentifier: "cell", cellType: MyTableViewCell.self))
        { (row, element, cell) in
            cell.labelOne.text = self.countriesArray[row]
            cell.labelTwo.text = self.currenciesArray[row]
        }.disposed(by: disposeBag)
    }
    
    func getCurrencyRatesList(){
        presenter.getCurrencyObjFromNS()
    }

    

    
}
