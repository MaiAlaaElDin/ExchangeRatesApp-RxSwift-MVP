//
//  Currency.swift
//  ExchangeRatesApp
//
//  Created by Mai Alaa on 5/27/19.
//  Copyright © 2019 Mai Alaa. All rights reserved.
//

import Foundation

// MARK: - Currency
struct Currency: Codable {
    var base: String
    var rates: [String: Double]
    var date: String
}
